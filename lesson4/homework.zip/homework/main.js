//Task 1

// let color;
// color = 'red';
// color = 'blue';
// let newColor = color;
// console.log(newColor);

//Task 2

// let num = prompt('Write number');
// if(num == 1 || num == 2 || num == 12){
//     alert('Winter');
// }
// else if(num>2 && num<6){
//     alert('Spring');
// }
// else if(num>5 && num<9){
//     alert('Summer');
// }
// else if(num>8 && num<12){
//     alert('Autumn');
// }
// else{
//     alert('There is no such a month!');
// }

//Task 3

// let i = 1000;
// do {
//   i += 5;
//   console.log(i);
// } while (i < 10000);

//Task 4
//
// let elem = document.querySelector('#box')
// elem.style.height = '50px';
// elem.style.width = '50px';
// elem.style.border = '1px solid #000';
// elem.style.background = 'blue';


